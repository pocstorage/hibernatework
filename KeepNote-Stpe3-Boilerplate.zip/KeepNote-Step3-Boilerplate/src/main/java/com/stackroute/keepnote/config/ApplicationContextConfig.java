package com.stackroute.keepnote.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.stackroute.keepnote.service.UserService;
import com.stackroute.keepnote.service.UserServiceImpl;

/*This class will contain the application-context for the application. 
 * Define the following annotations:
 * @Configuration - Annotating a class with the @Configuration indicates that the 
 *                  class can be used by the Spring IoC container as a source of 
 *                  bean definitions
 * @ComponentScan - this annotation is used to search for the Spring components amongst the application
 * @EnableWebMvc - Adding this annotation to an @Configuration class imports the Spring MVC 
 * 				   configuration from WebMvcConfigurationSupport 
 * @EnableTransactionManagement - Enables Spring's annotation-driven transaction management capability.
 *                  
 * 
 * */
@Configuration
@ComponentScan(basePackages = { "com.stackroute" })
@EnableWebMvc
@EnableTransactionManagement
public class ApplicationContextConfig {

	@Bean
	public DataSource dataSource() {
		BasicDataSource datasource = new BasicDataSource();
		datasource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		datasource.setUrl("jdbc:mysql://10.242.67.211:3306/keepnote3?createDatabaseIfNotExist=true");
		datasource.setUsername("root");
		datasource.setPassword("root");
		return datasource;
	}

	@Autowired
	@Bean
	public SessionFactory sessionFactory(DataSource dataSource) {
		LocalSessionFactoryBuilder sfactory = new LocalSessionFactoryBuilder(dataSource);
		sfactory.scanPackages("com.stackroute");
		sfactory.addProperties(gethbproperties());
		return sfactory.buildSessionFactory();
	}

	public Properties gethbproperties() {
		Properties hibernateproperties = new Properties();
		hibernateproperties.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");
		hibernateproperties.setProperty("hibernate.show_sql", "true");
		hibernateproperties.setProperty("hibernate.format_sql", "true");
		hibernateproperties.setProperty("hibernate.show_sql", "true");
		hibernateproperties.setProperty("hibernate.hbm2ddl.auto", "update");

		return hibernateproperties;
	}

	@Bean
	public HibernateTransactionManager platformTransactionManager(SessionFactory lsfactory) {
		HibernateTransactionManager htxmanager = new HibernateTransactionManager(lsfactory);
		return htxmanager;
	}

	

}
