package com.stackroute.keepnote.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Service;

import com.stackroute.keepnote.config.ApplicationContextConfig;
import com.stackroute.keepnote.dao.UserDAO;
import com.stackroute.keepnote.exception.UserAlreadyExistException;
import com.stackroute.keepnote.exception.UserNotFoundException;
import com.stackroute.keepnote.model.User;

/*
* Service classes are used here to implement additional business logic/validation 
* This class has to be annotated with @Service annotation.
* @Service - It is a specialization of the component annotation. It doesn�t currently 
* provide any additional behavior over the @Component annotation, but it�s a good idea 
* to use @Service over @Component in service-layer classes because it specifies intent 
* better. Additionally, tool support and additional behavior might rely on it in the 
* future.
* */
@Service
public class UserServiceImpl implements UserService {

	// @Autowired
	UserDAO userDAO;

	/*
	 * Autowiring should be implemented for the userDAO. (Use Constructor-based
	 * autowiring) Please note that we should not create any object using the new
	 * keyword.
	 */

	@Autowired
	public UserServiceImpl(UserDAO userDAO) {
		this.userDAO = userDAO;
	}
	/*
	 * This method should be used to save a new user.
	 */

	public boolean registerUser(User user) throws UserAlreadyExistException {
		boolean flag = false;
		if (userDAO.registerUser(user)) {
			flag = true;
		}
		return flag;

	}

	/*
	 * This method should be used to update a existing user.
	 */

	public User updateUser(User user, String userId) throws Exception {
		User updatedUser = null;

		if (null != userId) {
			updatedUser = userDAO.getUserById(userId);
			updatedUser.setUserId(userId);
			updatedUser.setUserAddedDate(user.getUserAddedDate());
			updatedUser.setUserMobile(user.getUserMobile());
			updatedUser.setUserName(user.getUserName());
			updatedUser.setUserPassword(user.getUserPassword());
			userDAO.registerUser(updatedUser);

		} else {
			throw new UserNotFoundException(userId);
		}

		return updatedUser;

	}

	/*
	 * This method should be used to get a user by userId.
	 */

	public User getUserById(String userId) throws UserNotFoundException {

		return userDAO.getUserById(userId);	

	}

	/*
	 * This method should be used to validate a user using userId and password.
	 */

	public boolean validateUser(String userId, String password) throws UserNotFoundException {
		return false;

	}

	/* This method should be used to delete an existing user. */
	public boolean deleteUser(String userId) {
		boolean flag = false;
		if (userDAO.deleteUser(userId)) {
			flag = true;
		}
		return flag;

	}

}
